---
layout: default
title: pages.faq.title
slug: faq
lead: pages.faq.lead
---

{% tf faq/faq.md %}

---

### How can I support development of bootstrap-table?

All your ideas and feedback are very appreciated! Please feel free to open issues on github or send me email.

I'm also grateful for your donations:

<script data-gratipay-username="wenzhixin" data-gratipay-widget="button" src="//gttp.co/v1.js"></script>

[![Donate](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZDHP676FQDUT6)

Thank you!
